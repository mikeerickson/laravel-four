/*
	app.js
	 created by:  Mike Erickson, codedungeon@gmail.com
	 created:     2013-09-02 16:50:31

	You can change either of these values:

		- timeInterval = number of milliseconds before div is displayed
		- checkInterval = number of milliseconds to check pool (The higher the value, the more latency)
*/


var timeInterval  = 1000*15	     // 1000*60*2 = 2 minutes (120 seconds, 1200 milliseconds)
,   checkInterval = 1000*2      // check interval (every 10 seconds it will check)
,   _nextTime      = cookie.get('nextTime');

// setup timer objects
if (typeof nextTime === 'undefined') {
	_nextTime = getNextTime();
	cookie.set('nextTime',_nextTime);
}

function checkTime () {
	_nextTime = cookie.get('nextTime');
	if(getCurrentTime() >= _nextTime)
		showDiv('test');
}

function getNextTime() {
	return new Date().getTime() + timeInterval;
}

function getCurrentTime() {
	return new Date().getTime();
}

function hideDiv() {
	document.getElementById('test').style.display = "none";
	_nextTime = getNextTime();
	cookie.set('nextTime',_nextTime);	// update counter
}

function showDiv(divID) {
	document.getElementById(divID).style.display = "inline";
}

setInterval(checkTime,checkInterval); // start checker thread (will check every 'check' intervals)
